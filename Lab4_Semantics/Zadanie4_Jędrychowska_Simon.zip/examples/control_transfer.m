x+=0;
x=0;
x/=0;
x = "halo";

while(k>0) {
    break;
    continue;
}

continue;

return x;

break;

return x+1;

x = 1.5;
return 2*x;



while(k>0) {
    break;
    continue;
}

print x;
