n = 10;
for i = 1:n print "*" * i;