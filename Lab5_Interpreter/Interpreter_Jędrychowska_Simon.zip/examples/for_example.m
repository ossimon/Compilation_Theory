n = 10;
a = 1;
for i = 1: n - 5 {
    a *= 2;
    print a, i;
    if (i == 3) break;
}